================================================

          NINJA GAIDEN SHADOW DX v1.0
             by NiO107 & marc_max

================================================


Ninja Gaiden Shadow is a unique entry in the Ninja Gaiden series that was
released exclusively for the original Game Boy.

Guide Ryu Hayabusa through five stages packed with pure ninja action and save
the world from the evil Emperor Garuda!

This new remastered version enhances the visual experience by giving it a new
coat of color!

FEATURES
- full color conversion
- slowdowns removed
- background tweaks and improvements
- works in real hardware and emulators



PATCHING INFORMATION
--------------------
You must provide the original Ninja Gaiden Shadow (USA) ROM:

Ninja Gaiden Shadow (USA).gb
CRC32: d3741a3a
MD5:   e12c5c2897ed095f8d26c7578afddfda
SHA-1: 8aadd7dfb4add75d5ac5351658762e5f56e78c66
 
Apply the patch here: https://www.romhacking.net/patch/
(some emulators may require a .gbc extension, so make sure you rename it after
patching)



CHANGELOG
---------
v1.0 (2025-12-24)
- first version



CREDITS
-------
NiO107 - graphics
marc_max - reverse engineering & hacking

thanks to all betatesters for their deep testing!
thanks to the GB Colorization team for their help and advice!
thanks to you for your patience!


DISCLAIMER
----------
This is a fan created hack, no copyright or trademark infringement is intended.
Ninja Gaiden is a trademark © of Koei Tecmo. We are not affiliated nor endorsed by Koei Tecmo.
